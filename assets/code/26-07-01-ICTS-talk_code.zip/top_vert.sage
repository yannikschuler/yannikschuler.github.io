## Functions for integer partitions.

from sage.combinat.partition import Partition

def kappa(self):
    """
    Returns the second Casimir invariant of the partition.
    """
    lam = list(self)
    return sum(lam[i] * (lam[i] - 2*(i+1) + 1) for i in range(len(lam)))


def aut_red(self):
    """
    Returns the second Casimir invariant of the partition.
    """
    return mul(factorial(mult) for mult in self.to_exp())

Partition.kappa = kappa
Partition.aut_red = aut_red

def intersectParts(mu, nu):
    """
    Returns the intersection of two partitions `mu` and `nu`.
    """
    mu = list(mu)
    nu = list(nu)
    return Partition([min(mu[i], nu[i]) for i in range(min(len(mu),len(nu)))])


## Setup of rings.

RRR.<q> = LaurentPolynomialRing(QQ)
FFF = RRR.fraction_field()

def setup_field(gens):
    """
    Sets up the function field in generators `gens` for performing topological
    vertex computations.
    """
    global RRR
    global FFF
    RRR = LaurentPolynomialRing(QQ, gens)
    FFF = RRR.fraction_field()
    return RRR.gens()

def adams(k):
    """
    `k`th Adams operation in the field FFF.
    """
    return Hom(FFF, FFF)([qq^k for qq in FFF.gens()])


## Symmetric functions preliminaries

Sym = SymmetricFunctions(QQ)

schur = Sym.schur()
psum = Sym.powersum()

def specialise_power_sum(lam, qq, mu):
    """
    Returns the power sum indexed by a partition `lam` with variables x1, x2, ...
    specialised to xi = qq^(2*mu_i - 2*i + 1).
    """
    lam = Partition(lam)
    if lam == Partition([]):
        return FFF.one()
    return FFF(1) * prod(1 / (qq**lam[i] - qq**(-lam[i])) +
                         sum(qq**(lam[i] * (2 * mu[j] - 2 * (j+1) + 1)) - qq**(lam[i] * (- 2 * (j+1) + 1))
                             for j in range(len(mu)) )
                         for i in range(len(lam)) )

def ppspecialise(qq, mu):
    """
    Takes a monomial `qq`` and an integer partition `mu` and returns a morphism that
    specialises the variables x1, x2, ... of a power sum to the xi = qq^(2*mu_i - 2*i + 1).
    """
    return psum.module_morphism(
        on_basis=lambda lam: specialise_power_sum(lam, qq, mu),
        codomain=FFF
    )


## The topological vertex

def top_vert(mu1, mu2, mu3, qq):
    """
    This function evaluates the topological vertex in the variable qq^2 for
    partitions `mu1`, `mu2`, `mu3`.
    """
    mu1 = Partition(mu1)
    mu2 = Partition(mu2)
    mu3 = Partition(mu3)

    # If one of the partitions is empty fall back to a cyclic reordering that avoids the
    # sum in the topological vertex formula.
    if mu1 == Partition([]):
        return FFF(1) * ppspecialise(qq, [])(psum(schur(mu3))) * ppspecialise(qq, mu3.conjugate())(psum(schur(mu2)))
    if mu2 == Partition([]):
        return top_vert(mu2, mu3, mu1, qq)
    if mu3 == Partition([]):
        return top_vert(mu3, mu1, mu2, qq)

    # If all partitions are non-empty we embrace the general formula
    mu1c = mu1.conjugate()
    mu3c = mu3.conjugate()
    nuMax = intersectParts(mu1, mu2)
    return FFF(1) * qq**(-mu1c.kappa()) * ppspecialise(qq, [])(psum(schur(mu3))) * sum(ppspecialise(qq, mu3)(psum(schur(mu1c).skew_by(schur(nu)))) *
                ppspecialise(qq, mu3c)(psum(schur(mu2).skew_by(schur(nu))))
                for nn in range(len(nuMax) + 1)
                for nu in Partitions(nn, outer=nuMax).list())


## Plethystic Log

from itertools import product as itprod

def get_multiplicities(vect):
    """
    This function calculates all s.c. multiplicities (in the sense of section A.2 of the paper)
    of a vector `vect` (or better list) with positive integer coefficients.
    """
    def get_n_max(vect, delta):
        """
        This function returns the maximum integer `max_n` such that vect - max_n * delta has
        positive entries. We assume that the arguments `vect`, `delta` are vectors (lists)
        with positive integer coefficients.
        """
        max_n = 10^5
        for i in range(len(vect)):
            if delta[i] != 0:
                max_n = min(max_n, round(float(vect[i]/delta[i])-0.1))
        return max_n

    def get_deltas(vect):
        """
        This function returns a list featuring all elements of the set D(vect) adopting the
        notation of section A.2 of the paper.
        """
        return list(itprod(*[range(vect[i]+1) for i in range(len(vect))]))[1:]

    def get_multiplicities_rec(vect, delta_list):
        """
        This function returns all possible lists of of positive integers [a1, a2, ...] which
        satisfy vect = a1 * delta1 + a2 * delta2 + ... where delta1, delta2, ... are the entries
        of the list `delta_list`.
        """
        n1_max = get_n_max(vect, delta_list[0])

        if len(delta_list) == 1:
            if all(vect[i] == n1_max * delta_list[0][i] for i in range(len(vect))):
                return [[n1_max]]
            else:
                return []

        n1_max = get_n_max(vect, delta_list[0])
        res = []

        for i in range(n1_max + 1):
            multipls_rec = get_multiplicities_rec([vect[j] - i * delta_list[0][j] for j in range(len(vect))], delta_list[1:])

            if multipls_rec != []:
                for mult in multipls_rec:
                    mult.insert(0, i)
                    res.append(mult)

        return res

    delta_list = get_deltas(vect)
    multipls = get_multiplicities_rec(vect, delta_list)
    return delta_list, multipls

def get_multiplicities_gcd_free(vect):
    """
    This function calculates all s.c. multiplicities (n_delta)_{delta in D(vect)} (in the
    sense of section A.2 of the paper) of a vector `vect` (or better list) with positive
    integer coefficients with gcd(n_delta)_delta = 1.
    """
    delta_list, multipls = get_multiplicities(vect)
    multipls_gcd_free = []

    for multip in multipls:
        if gcd(multip)==1:
            multipls_gcd_free.append(multip)

    return delta_list, multipls_gcd_free

def PLog_coeff(Z_list, dvec):
    """
    This function takes a nested list `Z_list` which at position (d1, ...) stores the coefficient
    Z_{d1, ...} of a power series Z(Q) = sum_{d1, ... >= 0} Z_{d1, ...} Q1^d1 * Q2^d2 * ... satisfying
    Z(0) = 1. It returns the coefficient of the monomial Q^{dvec} of the plethystic logarithm of Z(Q).
    """
    def get_coeff(Z_list, dvec):
        if len(dvec) > 1:
            return get_coeff(Z_list[dvec[0]], dvec[1:])
        else:
            return Z_list[dvec[0]]


    if sum(dvec) == 0:
        return 0

    res = 0
    for k in divisors(gcd(dvec)):
        delta_list, multipls = get_multiplicities_gcd_free([di/k for di in dvec])
        for nn in multipls:
            nn_abs = sum(nn)

            Z_prod = FFF(1)
            for i in range(len(nn)):
                if nn[i]!=0:
                    Z_prod *= get_coeff(Z_list,delta_list[i])**(nn[i])

            res -= FFF(1) / k / nn_abs * sum( (-1)**(kprime * nn_abs) * moebius(k / kprime) * factorial(kprime * nn_abs) * adams(k/kprime)( mul( get_coeff(Z_list,delta_list[i])**(nn[i] * kprime) / factorial(kprime * nn[i]) for i in range(len(delta_list))) ) for kprime in divisors(k))
    return res

def PLog(Z_list):
    """
    This function takes a nested list `Z_list` which at position (d1, ...) stores the coefficient
    Z_{d1, ...} of a power series Z(Q) = sum_{d1, ... >= 0} Z_{d1, ...} Q1^d1 * Q2^d2 * ... satisfying
    Z(0) = 1. It returns a nested list which at position (d1, ...) stores the coefficient of
    Q1^d1 * Q2^d2 * ... of the plethystic logarithm of Z(Q).
    """
    def get_max_degs(Z_list):
        """
        Determines the dimensions of a nested list `Z_list`.
        """
        if isinstance(Z_list[0], list):
            return [len(Z_list)] + get_max_degs(Z_list[0])
        else:
            return [len(Z_list)]

    def PLog_nested_list_rec(dvec, max_degs, Z_list):
        """
        This function recursively goes through the positions of the nested list `Z_list` and
        determines the coefficient of the plethystic logarithm at each position.
        """
        if len(max_degs) > 1:
            return [PLog_nested_list_rec(dvec + [di], max_degs[1:], Z_list) for di in range(max_degs[0])]
        else:
            return [PLog_coeff(Z_list, dvec + [di]) for di in range(max_degs[0])]

    max_degs = get_max_degs(Z_list)
    return PLog_nested_list_rec([], max_degs, Z_list)
